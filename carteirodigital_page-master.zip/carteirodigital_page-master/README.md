# Carteiro Digital 📦

Rastreie encomendas dos Correios do Brasil pelo Telegram. Simples, rápido e grátis.

## Tecnologias utilizadas
- HTML
- CSS
- Javascript
- Bootstrap
- Scroll Reveal
- Axios

## Projetos relacionados - repositórios
- [Carteiro Digital - Bot](https://github.com/jeancarlospaula/carteirodigital_bot)
- [Carteiro Digital - API](https://github.com/jeancarlospaula/carteirodigital_api)


![screencapture-127-0-0-1-5500-2022-09-26-18_24_41 (1)](https://user-images.githubusercontent.com/79765050/192383465-fafa3995-4d97-43ef-b9c2-5036760b69ce.png)
